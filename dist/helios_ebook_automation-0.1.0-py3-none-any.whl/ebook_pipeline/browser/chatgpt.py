from __future__ import annotations

import importlib
import json
import logging
from collections.abc import Callable, Mapping
from pathlib import Path
from time import monotonic
from types import ModuleType
from typing import Any, TypedDict
from urllib.parse import urlparse
from uuid import uuid4

from ebook_pipeline.browser.capture_comparison import compare_capture_text
from ebook_pipeline.browser.fingerprints import transport_fingerprint
from ebook_pipeline.browser.models import (
    BootstrapCandidate,
    CaptureSpikeResult,
    ComposerProbeCaseResult,
    SessionState,
    TurnInspection,
    TurnState,
)
from ebook_pipeline.browser.profile_lock import BrowserProfileLock
from ebook_pipeline.browser.selectors import (
    ASSISTANT_MESSAGE_SELECTOR,
    CHALLENGE_PATTERN,
    COMPOSER_EDITOR_SELECTOR,
    COMPOSER_TEST_ID,
    CONVERSATION_LINK_SELECTOR,
    COPY_PATTERN,
    LOGIN_PATTERN,
    OPERATIONAL_ERROR_PATTERN,
    RETRY_PATTERN,
    SEND_BUTTON_TEST_ID,
    SEND_PATTERN,
    STOP_PATTERN,
    TURN_SELECTOR,
    USER_MESSAGE_SELECTOR,
)
from ebook_pipeline.browser.urls import (
    conversation_path_from_page_url,
    is_real_conversation_path,
)
from ebook_pipeline.core.errors import (
    ConfigurationError,
    ConflictError,
    HeliosError,
    IntegrityError,
)
from ebook_pipeline.core.hashing import sha256_bytes
from ebook_pipeline.core.ids import utc_now

LOGGER = logging.getLogger(__name__)
COMPOSER_FILL_MAX_CHARACTERS = 32_768


class ComposerMetadata(TypedDict):
    tag_name: str
    contenteditable: str | None
    role: str | None
    id: str | None
    data_testid: str | None
    is_content_editable: bool
    focused: bool
    editable_descendant_count: int


SPIKE_PROMPTS = {
    "acknowledgement": (
        "Teste técnico de captura Hélios {marker}. Responda em texto simples, sem Markdown, "
        "com uma única frase curta confirmando que recebeu esta mensagem."
    ),
    "long_unit": (
        "Teste técnico de captura Hélios {marker}. Produza entre 3.500 e 4.000 caracteres em "
        "texto simples contínuo, sem Markdown, listas ou títulos, explicando de forma neutra "
        "como persistência, idempotência e recuperação tornam um pipeline local confiável. "
        "Não mencione estas instruções e não inclua dados pessoais."
    ),
}


class ChatGPTWebAdapter:
    """All ChatGPT DOM knowledge lives here; domain services see only the port."""

    def __init__(
        self,
        *,
        profile_dir: Path,
        browser_channel: str,
        base_url: str,
        headless: bool,
        timeout_seconds: int,
        capture_method_version: str,
    ) -> None:
        self.profile_dir = profile_dir
        if browser_channel not in {"chrome", "chromium"}:
            raise IntegrityError(
                "BROWSER_CHANNEL_UNSUPPORTED", f"Unsupported browser channel: {browser_channel}"
            )
        self.browser_channel = browser_channel
        self.base_url = base_url.rstrip("/")
        self.headless = headless
        self.timeout_ms = timeout_seconds * 1000
        self.capture_method_version = capture_method_version
        self._playwright: Any = None
        self._context: Any = None
        self._page: Any = None
        self._profile_lock = BrowserProfileLock(profile_dir)

    def _module(self) -> ModuleType:
        try:
            return importlib.import_module("playwright.sync_api")
        except ImportError as exc:
            raise IntegrityError(
                "PLAYWRIGHT_NOT_INSTALLED",
                "Install the M3 browser dependency before browser setup",
            ) from exc

    def _start(self) -> Any:
        if self._page is not None:
            return self._page
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self._profile_lock.acquire()
        try:
            module = self._module()
            self._playwright = module.sync_playwright().start()
            options: dict[str, object] = {"headless": self.headless}
            if self.browser_channel == "chrome":
                options["channel"] = "chrome"
            self._context = self._playwright.chromium.launch_persistent_context(
                str(self.profile_dir),
                **options,
            )
        except Exception as exc:
            if self._playwright is not None:
                self._playwright.stop()
                self._playwright = None
            self._profile_lock.release()
            if self._is_profile_in_use_error(exc):
                raise ConflictError(
                    "BROWSER_PROFILE_IN_USE",
                    "Close Chrome or Playwright using the dedicated profile before retrying",
                ) from exc
            raise
        self._context.set_default_timeout(self.timeout_ms)
        self._page = self._context.pages[0] if self._context.pages else self._context.new_page()
        return self._page

    def ensure_ready(self) -> SessionState:
        page = self._start()
        if not page.url.startswith(self.base_url):
            page.goto(self.base_url, wait_until="domcontentloaded")
        body = page.locator("body").inner_text(timeout=self.timeout_ms)
        if CHALLENGE_PATTERN.search(body):
            return SessionState.CHALLENGE
        if page.get_by_role("button", name=LOGIN_PATTERN).count() or page.get_by_role(
            "link", name=LOGIN_PATTERN
        ).count():
            return SessionState.LOGIN_REQUIRED
        if not self._composer().count():
            return SessionState.LOGIN_REQUIRED
        return SessionState.READY

    def create_conversation(self) -> None:
        self._start().goto(self.base_url, wait_until="domcontentloaded")

    def open_conversation(self, conversation_path: str) -> None:
        if not is_real_conversation_path(conversation_path):
            raise IntegrityError(
                "BROWSER_CONVERSATION_PATH_INVALID",
                "Conversation path is not a canonical /c/<uuid> path",
            )
        self._start().goto(f"{self.base_url}{conversation_path}", wait_until="domcontentloaded")

    def list_conversation_paths(self) -> tuple[str, ...]:
        links = self._start().locator(CONVERSATION_LINK_SELECTOR)
        result: set[str] = set()
        for index in range(links.count()):
            href = links.nth(index).get_attribute("href")
            if href:
                parsed = urlparse(href)
                path = (
                    conversation_path_from_page_url(href)
                    if parsed.netloc
                    else parsed.path
                )
                if path is not None and is_real_conversation_path(path):
                    result.add(path)
        return tuple(sorted(result))

    def send_message(
        self,
        text: str,
        *,
        prefilled: bool = False,
        on_send_attempt_started: Callable[[], None] | None = None,
    ) -> str | None:
        if not text:
            raise IntegrityError("BROWSER_REQUEST_EMPTY", "Browser request text is empty")
        composer = self._composer()
        if composer.count() != 1:
            raise ConflictError(
                "BROWSER_COMPOSER_AMBIGUOUS", "Expected exactly one ChatGPT message composer"
            )
        self._audit_composer(composer, phase="located")
        self._send_checkpoint("composer_found")
        try:
            composer.click(timeout=self.timeout_ms)
            composer.focus(timeout=self.timeout_ms)
        except Exception as exc:
            raise ConflictError(
                "BROWSER_COMPOSER_FOCUS_FAILED",
                "The resolved ChatGPT editor could not be focused",
            ) from exc
        focused_metadata = self._audit_composer(composer, phase="focused")
        if not focused_metadata["focused"]:
            raise ConflictError(
                "BROWSER_COMPOSER_FOCUS_FAILED",
                "The resolved ChatGPT editor did not retain focus",
            )
        expected_fingerprint = transport_fingerprint(text)
        if not prefilled:
            try:
                composer = self._insert_composer_text(composer, text)
            except HeliosError:
                raise
            except Exception as exc:
                raise ConflictError(
                    "BROWSER_COMPOSER_FILL_FAILED",
                    "The ChatGPT composer could not be filled",
                ) from exc
        self._wait_for_composer_fingerprint(composer, expected_fingerprint)
        self._send_checkpoint("composer_filled")
        send_button = self._send_button()
        if send_button.count() != 1:
            raise ConflictError(
                "BROWSER_SEND_CONTROL_AMBIGUOUS",
                "Expected exactly one ChatGPT send button",
            )
        self._send_checkpoint("send_button_found")
        try:
            if not send_button.is_visible():
                raise ConflictError(
                    "BROWSER_SEND_BUTTON_NOT_VISIBLE",
                    "The ChatGPT send button exists but is not visible",
                )
            if not send_button.is_enabled():
                raise ConflictError(
                    "BROWSER_SEND_BUTTON_DISABLED",
                    "The ChatGPT send button exists but is disabled",
                )
        except ConflictError:
            raise
        except Exception as exc:
            raise ConflictError(
                "BROWSER_SEND_BUTTON_NOT_ACTIONABLE",
                "The ChatGPT send button actionability could not be determined",
            ) from exc
        self._send_checkpoint("send_button_enabled")
        if on_send_attempt_started is not None:
            on_send_attempt_started()
        self._send_checkpoint("send_trigger_started")
        try:
            send_button.click(timeout=self.timeout_ms)
        except Exception as exc:
            raise ConflictError(
                "BROWSER_SEND_BUTTON_NOT_ACTIONABLE",
                "The ChatGPT send button click did not complete",
            ) from exc
        self._send_checkpoint("send_trigger_completed")
        page = self._start()
        deadline = monotonic() + self.timeout_ms / 1000
        while True:
            if not self._composer_has_text():
                self._send_checkpoint("composer_cleared")
                break
            if monotonic() >= deadline:
                raise ConflictError(
                    "BROWSER_SEND_COMPOSER_NOT_CLEARED",
                    "The click completed but the request remained in the composer",
                )
            page.wait_for_timeout(100)
        return None

    def composer_probe(
        self, payloads: Mapping[str, str]
    ) -> dict[str, ComposerProbeCaseResult]:
        """Exercise composer insertion only; this method has no send-control code path."""
        if self.headless or self.browser_channel != "chrome":
            raise ConfigurationError(
                "BROWSER_COMPOSER_SPIKE_REQUIRES_HEADED_CHROME",
                "Composer spike requires headed Google Chrome with the dedicated profile",
            )
        if self.ensure_ready() is not SessionState.READY:
            raise IntegrityError(
                "BROWSER_LOGIN_REQUIRED",
                "The ChatGPT session is not ready; run the manual browser bootstrap",
            )
        self.create_conversation()
        self._clear_composer()
        results: dict[str, ComposerProbeCaseResult] = {}
        for case_name, payload in payloads.items():
            try:
                results[case_name] = self._probe_composer_payload(payload)
            finally:
                self._clear_composer()
        return results

    def current_conversation_path(self) -> str | None:
        return self._path()

    def inspect_turn(self, requested_fingerprint: str) -> TurnInspection:
        page = self._start()
        turns = page.locator(TURN_SELECTOR)
        matches: list[int] = []
        for index in range(turns.count()):
            message = turns.nth(index)
            if (
                message.get_attribute("data-message-author-role") == "user"
                and transport_fingerprint(message.inner_text()) == requested_fingerprint
            ):
                matches.append(index)
        if not matches:
            return TurnInspection(TurnState.NOT_SENT, self._path())
        if len(matches) != 1:
            return TurnInspection(
                TurnState.AMBIGUOUS,
                self._path(),
                evidence={"matching_user_turns": len(matches)},
            )
        observed_fingerprint = transport_fingerprint(turns.nth(matches[0]).inner_text())
        next_index = matches[0] + 1
        if next_index >= turns.count():
            return TurnInspection(
                TurnState.STREAMING,
                self._path(),
                evidence={"assistant_started": False},
                observed_user_turn_fingerprint=observed_fingerprint,
            )
        assistant = turns.nth(next_index)
        if assistant.get_attribute("data-message-author-role") != "assistant":
            return TurnInspection(
                TurnState.AMBIGUOUS,
                self._path(),
                evidence={"assistant_turns": 0},
                observed_user_turn_fingerprint=observed_fingerprint,
            )
        if page.get_by_role("button", name=STOP_PATTERN).count():
            return TurnInspection(
                TurnState.STREAMING,
                self._path(),
                evidence={"assistant_started": True},
                observed_user_turn_fingerprint=observed_fingerprint,
            )
        first = assistant.inner_text()
        page.wait_for_timeout(250)
        second = assistant.inner_text()
        if first != second:
            return TurnInspection(
                TurnState.STREAMING,
                self._path(),
                evidence={"assistant_started": True},
                observed_user_turn_fingerprint=observed_fingerprint,
            )
        if not second.strip():
            return TurnInspection(TurnState.AMBIGUOUS, self._path())
        return TurnInspection(
            TurnState.COMPLETE,
            self._path(),
            second,
            evidence={"assistant_started": True},
            observed_user_turn_fingerprint=observed_fingerprint,
        )

    def find_bootstrap_candidates(
        self, requested_fingerprint: str, started_at: str
    ) -> tuple[BootstrapCandidate, ...]:
        del started_at  # The caller additionally enforces the persisted operational baseline.
        current_path = self._path()
        candidates: list[BootstrapCandidate] = []
        for path in self.list_conversation_paths():
            self.open_conversation(path)
            inspection = self.inspect_turn(requested_fingerprint)
            if (
                inspection.state in {TurnState.STREAMING, TurnState.COMPLETE}
                and inspection.observed_user_turn_fingerprint == requested_fingerprint
            ):
                candidates.append(
                    BootstrapCandidate(
                        path, inspection.observed_user_turn_fingerprint, utc_now()
                    )
                )
        if current_path is not None:
            self.open_conversation(current_path)
        return tuple(candidates)

    def capture_spike(self, sample_kind: str) -> CaptureSpikeResult:
        if sample_kind not in {"acknowledgement", "long_unit"}:
            raise IntegrityError(
                "BROWSER_CAPTURE_SPIKE_KIND_INVALID", "Unknown capture spike sample kind"
            )
        if self.ensure_ready() is not SessionState.READY:
            raise IntegrityError(
                "BROWSER_LOGIN_REQUIRED",
                "The ChatGPT session is not ready; run the manual browser bootstrap",
            )
        self._spike_checkpoint("provider_ready")
        self.create_conversation()
        self._spike_checkpoint("conversation_ready")

        composer = self._composer()
        if composer.count() != 1:
            raise ConflictError(
                "BROWSER_SPIKE_COMPOSER_NOT_FOUND",
                "Expected exactly one composer for the capture spike",
            )
        self._spike_checkpoint("composer_found")
        spike_marker = f"HELIOS-SPIKE-{uuid4()}"
        prompt = SPIKE_PROMPTS[sample_kind].format(marker=spike_marker)
        try:
            composer.fill(prompt)
        except Exception as exc:
            raise ConflictError(
                "BROWSER_SPIKE_COMPOSER_NOT_FOUND",
                "The spike composer could not be filled",
            ) from exc
        self._spike_checkpoint("composer_filled")
        try:
            self.send_message(prompt, prefilled=True)
        except Exception as exc:
            raise ConflictError(
                "BROWSER_SPIKE_PROMPT_NOT_SENT",
                "The synthetic capture-spike prompt could not be sent",
            ) from exc
        if self._composer_has_text():
            raise ConflictError(
                "BROWSER_SPIKE_PROMPT_NOT_SENT",
                "The send action completed but the synthetic prompt remained in the composer",
            )
        self._spike_checkpoint("send_triggered")

        fingerprint = transport_fingerprint(prompt)
        inspection = self._wait_for_spike_user_turn(fingerprint)
        self._spike_checkpoint("user_turn_observed")
        inspection = self._wait_for_spike_response_start(fingerprint, inspection)
        self._spike_checkpoint("assistant_response_started")
        inspection = self._wait_for_spike_completion(fingerprint, inspection)
        self._spike_checkpoint("assistant_response_completed")
        if not inspection.response_text or not inspection.response_text.strip():
            raise IntegrityError(
                "BROWSER_SPIKE_RESPONSE_EMPTY", "The completed spike response is empty"
            )

        try:
            turn = self._assistant_for_fingerprint(fingerprint)
        except ConflictError as exc:
            raise ConflictError(
                "BROWSER_SPIKE_ASSISTANT_TURN_NOT_FOUND",
                "Cannot locate exactly one assistant turn for the synthetic spike prompt",
            ) from exc
        assistant = self._assistant_content(turn)
        if assistant.count() != 1:
            raise ConflictError(
                "BROWSER_SPIKE_ASSISTANT_TURN_NOT_FOUND",
                "Cannot locate exactly one assistant response for the synthetic spike prompt",
            )
        rendered_text = assistant.inner_text()
        if not isinstance(rendered_text, str) or not rendered_text.strip():
            raise IntegrityError(
                "BROWSER_SPIKE_RESPONSE_EMPTY", "The rendered spike response is empty"
            )
        rendered = rendered_text.encode("utf-8", errors="strict")
        self._spike_checkpoint("rendered_capture")

        copy_button = self._copy_button_for_assistant(assistant)
        if copy_button.count() != 1:
            raise ConflictError(
                "BROWSER_COPY_CAPTURE_UNAVAILABLE",
                "The Copy control is absent or ambiguous for the spike assistant turn",
            )
        clipboard = self._activate_copy_and_read(copy_button)
        if not isinstance(clipboard, str) or not clipboard.strip():
            raise IntegrityError(
                "BROWSER_SPIKE_RESPONSE_EMPTY", "The copied spike response is empty"
            )
        copied = clipboard.encode("utf-8", errors="strict")
        self._spike_checkpoint("copy_capture")
        result = CaptureSpikeResult(
            sample_kind=sample_kind,
            rendered_sha256=sha256_bytes(rendered),
            copied_sha256=sha256_bytes(copied),
            equivalent=copied == rendered,
            selected_method_version=self.capture_method_version,
            comparison=compare_capture_text(rendered_text, clipboard),
        )
        if self.capture_method_version not in {"rendered_text_v1", "copy_text_v1"}:
            raise IntegrityError(
                "BROWSER_CAPTURE_METHOD_UNSUPPORTED", "Unsupported capture method version"
            )
        if self.capture_method_version == "copy_text_v1":
            selected_size = len(copied)
        else:
            selected_size = len(rendered)
        if sample_kind == "acknowledgement" and selected_size > 2000:
            raise ConflictError(
                "BROWSER_CAPTURE_SPIKE_SAMPLE_INVALID",
                "Acknowledgement spike must use a short assistant response",
            )
        if sample_kind == "long_unit" and selected_size < 3000:
            raise ConflictError(
                "BROWSER_CAPTURE_SPIKE_SAMPLE_INVALID",
                "Long-unit spike must use a substantial assistant response",
            )
        marker: dict[str, object] = {"samples": {}}
        try:
            loaded = json.loads(self._capture_gate_path().read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                marker = loaded
        except (OSError, json.JSONDecodeError):
            pass
        samples = marker.get("samples")
        if not isinstance(samples, dict):
            samples = {}
        history = marker.get("history")
        if not isinstance(history, list):
            history = []
        previous_sample = samples.get(sample_kind)
        if isinstance(previous_sample, dict):
            history.append({"sample_kind": sample_kind, **previous_sample})
        samples[sample_kind] = {
            "comparison": result.comparison,
            "equivalent": result.equivalent,
            "rendered_sha256": result.rendered_sha256,
            "copied_sha256": result.copied_sha256,
        }
        marker = {
            "history": history,
            "samples": samples,
            "selected_method_version": result.selected_method_version,
        }
        self._capture_gate_path().parent.mkdir(parents=True, exist_ok=True)
        self._capture_gate_path().write_text(
            json.dumps(marker, sort_keys=True),
            encoding="utf-8",
        )
        return result

    def _wait_for_spike_user_turn(self, fingerprint: str) -> TurnInspection:
        deadline = monotonic() + min(15.0, self.timeout_ms / 1000)
        while monotonic() < deadline:
            inspection = self.inspect_turn(fingerprint)
            if inspection.state is TurnState.AMBIGUOUS:
                raise ConflictError(
                    "BROWSER_SPIKE_ASSISTANT_TURN_NOT_FOUND",
                    "The spike turn structure is ambiguous",
                )
            if inspection.state is not TurnState.NOT_SENT:
                return inspection
            self._start().wait_for_timeout(100)
        LOGGER.debug(
            "browser_capture_spike checkpoint=user_turn_timeout evidence=%s",
            json.dumps(self._spike_dom_evidence(), sort_keys=True),
            extra={
                "operation": "browser.capture_spike",
                "status": "user_turn_timeout",
            },
        )
        raise IntegrityError(
            "BROWSER_SPIKE_USER_TURN_NOT_OBSERVED",
            "The synthetic prompt was triggered but its user turn was not observed",
        )

    def _wait_for_spike_response_start(
        self, fingerprint: str, inspection: TurnInspection
    ) -> TurnInspection:
        deadline = monotonic() + self.timeout_ms / 1000
        current = inspection
        while monotonic() < deadline:
            if current.state is TurnState.COMPLETE or bool(
                (current.evidence or {}).get("assistant_started")
            ):
                return current
            current = self.inspect_turn(fingerprint)
            if current.state is TurnState.AMBIGUOUS:
                raise ConflictError(
                    "BROWSER_SPIKE_ASSISTANT_TURN_NOT_FOUND",
                    "The assistant turn became ambiguous before response start",
                )
            self._start().wait_for_timeout(100)
        LOGGER.debug(
            "browser_capture_spike checkpoint=response_start_timeout evidence=%s",
            json.dumps(self._spike_dom_evidence(), sort_keys=True),
            extra={
                "operation": "browser.capture_spike",
                "status": "response_start_timeout",
            },
        )
        raise IntegrityError(
            "BROWSER_SPIKE_RESPONSE_NOT_STARTED",
            "The user turn was observed but no assistant response started",
        )

    def _wait_for_spike_completion(
        self, fingerprint: str, inspection: TurnInspection
    ) -> TurnInspection:
        deadline = monotonic() + self.timeout_ms / 1000
        current = inspection
        while monotonic() < deadline:
            if current.state is TurnState.COMPLETE:
                return current
            if current.state is TurnState.AMBIGUOUS:
                raise ConflictError(
                    "BROWSER_SPIKE_ASSISTANT_TURN_NOT_FOUND",
                    "The assistant turn became ambiguous during generation",
                )
            current = self.inspect_turn(fingerprint)
            self._start().wait_for_timeout(250)
        raise IntegrityError(
            "BROWSER_SPIKE_RESPONSE_TIMEOUT",
            "The spike response did not complete before the configured timeout",
        )

    @staticmethod
    def _spike_checkpoint(checkpoint: str) -> None:
        LOGGER.debug(
            "browser_capture_spike checkpoint=%s",
            checkpoint,
            extra={
                "operation": "browser.capture_spike",
                "status": checkpoint,
            },
        )

    @staticmethod
    def _send_checkpoint(checkpoint: str) -> None:
        LOGGER.debug(
            "browser_send checkpoint=%s",
            checkpoint,
            extra={
                "operation": "browser.send_message",
                "status": checkpoint,
            },
        )

    def _spike_dom_evidence(self) -> dict[str, object]:
        page = self._start()
        composer = self._composer()
        body_text = page.locator("body").inner_text(timeout=min(5000, self.timeout_ms))
        return {
            "alert_count": page.get_by_role("alert").count(),
            "assistant_role_count": page.locator(ASSISTANT_MESSAGE_SELECTOR).count(),
            "composer_count": composer.count(),
            "composer_has_text": self._composer_has_text(),
            "conversation_path": self._path(),
            "operational_error_detected": bool(OPERATIONAL_ERROR_PATTERN.search(body_text)),
            "retry_control_count": page.get_by_role("button", name=RETRY_PATTERN).count(),
            "stop_control_count": page.get_by_role("button", name=STOP_PATTERN).count(),
            "turn_count": page.locator(TURN_SELECTOR).count(),
            "user_role_count": page.locator(USER_MESSAGE_SELECTOR).count(),
        }

    def capture_response(self, requested_fingerprint: str) -> str:
        turn = self._assistant_for_fingerprint(requested_fingerprint)
        assistant = self._assistant_content(turn)
        if self.capture_method_version == "rendered_text_v1":
            text = assistant.inner_text()
            if not isinstance(text, str) or not text.strip():
                raise IntegrityError("BROWSER_RESPONSE_EMPTY", "Captured response is empty")
            return str(text)
        if self.capture_method_version == "copy_text_v1":
            button = self._copy_button_for_assistant(assistant)
            if button.count() != 1:
                raise ConflictError(
                    "BROWSER_COPY_CAPTURE_UNAVAILABLE",
                    "Copy capture control is absent or ambiguous",
                )
            value = self._activate_copy_and_read(button)
            if not isinstance(value, str) or not value.strip():
                raise IntegrityError("BROWSER_RESPONSE_EMPTY", "Copied response is empty")
            return str(value)
        raise IntegrityError(
            "BROWSER_CAPTURE_METHOD_UNSUPPORTED", "Unsupported capture method version"
        )

    def capture_gate_ready(self) -> bool:
        try:
            value = json.loads(self._capture_gate_path().read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        if not isinstance(value, dict):
            return False
        selected = value.get("selected_method_version")
        samples = value.get("samples")
        return (
            isinstance(selected, str)
            and selected == self.capture_method_version
            and isinstance(samples, dict)
            and {"acknowledgement", "long_unit"}.issubset(samples)
        )

    def close(self) -> None:
        try:
            if self._context is not None:
                try:
                    self._context.close()
                except Exception:
                    LOGGER.debug(
                        "Ignoring browser context error during interruption cleanup",
                        exc_info=True,
                    )
                finally:
                    self._context = None
                    self._page = None
        finally:
            try:
                if self._playwright is not None:
                    try:
                        self._playwright.stop()
                    except Exception:
                        LOGGER.debug(
                            "Ignoring Playwright stop error during interruption cleanup",
                            exc_info=True,
                        )
                    finally:
                        self._playwright = None
            finally:
                self._profile_lock.release()

    def _composer(self) -> Any:
        page = self._start()
        by_id = page.locator(COMPOSER_TEST_ID)
        candidates: list[Any] = []
        for index in range(by_id.count()):
            candidate = by_id.nth(index)
            if self._is_visible_editor(candidate):
                candidates.append(candidate)
                continue
            descendants = candidate.locator(COMPOSER_EDITOR_SELECTOR)
            candidates.extend(
                descendants.nth(child_index)
                for child_index in range(descendants.count())
                if self._is_visible_editor(descendants.nth(child_index))
            )
        if not candidates:
            textboxes = page.get_by_role("textbox")
            candidates.extend(
                textboxes.nth(index)
                for index in range(textboxes.count())
                if self._is_visible_editor(textboxes.nth(index))
            )
        if len(candidates) == 1:
            return candidates[0]
        return page.locator("__helios_missing_or_ambiguous_composer__")

    def _send_button(self) -> Any:
        page = self._start()
        by_id = page.locator(SEND_BUTTON_TEST_ID)
        return by_id if by_id.count() else page.get_by_role("button", name=SEND_PATTERN)

    def _composer_has_text(self) -> bool:
        composer = self._composer()
        if composer.count() != 1:
            return False
        try:
            return bool(self._composer_text(composer).strip())
        except Exception:
            return False

    def _probe_composer_payload(self, payload: str) -> ComposerProbeCaseResult:
        if not payload:
            raise IntegrityError(
                "BROWSER_COMPOSER_SPIKE_PAYLOAD_EMPTY",
                "Composer probe payload must not be empty",
            )
        composer = self._composer()
        if composer.count() != 1:
            raise ConflictError(
                "BROWSER_COMPOSER_AMBIGUOUS",
                "Expected exactly one ChatGPT message composer",
            )
        self._audit_composer(composer, phase="probe_located")
        try:
            composer.click(timeout=self.timeout_ms)
            composer.focus(timeout=self.timeout_ms)
        except Exception as exc:
            raise ConflictError(
                "BROWSER_COMPOSER_FOCUS_FAILED",
                "The composer probe could not focus the resolved editor",
            ) from exc
        metadata = self._audit_composer(composer, phase="probe_focused")
        if not metadata["focused"]:
            raise ConflictError(
                "BROWSER_COMPOSER_FOCUS_FAILED",
                "The composer probe editor did not retain focus",
            )
        try:
            composer = self._insert_composer_text(composer, payload)
        except HeliosError:
            raise
        except Exception as exc:
            raise ConflictError(
                "BROWSER_COMPOSER_SPIKE_FILL_FAILED",
                "The composer probe payload could not be inserted",
            ) from exc
        expected = transport_fingerprint(payload)
        read_1, read_2, observed, observed_length = self._stable_composer_reads(
            composer, expected, reacquire=True
        )
        LOGGER.debug(
            "browser_composer_spike expected_length=%s observed_length=%s "
            "expected_fingerprint=%s observed_fingerprint=%s stable_read_1=%s "
            "stable_read_2=%s editor_metadata=%s",
            len(payload),
            observed_length,
            expected,
            observed,
            read_1,
            read_2,
            json.dumps(dict(metadata), sort_keys=True),
            extra={"operation": "browser.composer_spike", "status": "verified"},
        )
        return ComposerProbeCaseResult(
            expected_length=len(payload),
            observed_length=observed_length,
            expected_fingerprint=expected,
            observed_fingerprint=observed,
            stable_read_1=read_1,
            stable_read_2=read_2,
            editor_metadata=dict(metadata),
        )

    def _insert_composer_text(self, composer: Any, text: str) -> Any:
        live_editor = self._composer()
        if live_editor.count() != 1:
            raise ConflictError(
                "BROWSER_COMPOSER_AMBIGUOUS",
                "Expected exactly one live editor before composer insertion",
            )
        if len(text) <= COMPOSER_FILL_MAX_CHARACTERS:
            try:
                live_editor.fill(text, timeout=min(30_000, self.timeout_ms), force=True)
                return live_editor
            except Exception:
                live_editor = self._composer()
                if live_editor.count() == 1:
                    try:
                        observed = self._composer_text(live_editor)
                    except Exception:
                        observed = ""
                    if transport_fingerprint(observed) == transport_fingerprint(text):
                        LOGGER.debug(
                            "browser_composer_insert fill_timeout_but_verified=true",
                            extra={
                                "operation": "browser.composer.insert",
                                "status": "verified",
                            },
                        )
                        return live_editor
        LOGGER.debug(
            "browser_composer_insert fallback=keyboard_insert_text",
            extra={
                "operation": "browser.composer.insert",
                "status": "fallback",
            },
        )
        live_editor = self._composer()
        if live_editor.count() != 1:
            raise ConflictError(
                "BROWSER_COMPOSER_AMBIGUOUS",
                "Expected exactly one live editor before fallback insertion",
            )
        metadata = self._audit_composer(live_editor, phase="fallback_focused")
        if not metadata["focused"]:
            raise ConflictError(
                "BROWSER_COMPOSER_FOCUS_FAILED",
                "Fallback insertion requires the proven focused editor",
            )
        action_timeout = min(5000, self.timeout_ms)
        live_editor.press("Control+A", timeout=action_timeout)
        live_editor.press("Backspace", timeout=action_timeout)
        LOGGER.debug(
            "browser_composer_insert fallback_cleared=true",
            extra={
                "operation": "browser.composer.insert",
                "status": "fallback_cleared",
            },
        )
        keyboard = self._start().keyboard
        chunk_size = 4096
        chunk_count = (len(text) + chunk_size - 1) // chunk_size
        for offset in range(0, len(text), chunk_size):
            chunk_end = min(offset + chunk_size, len(text))
            keyboard.insert_text(text[offset:chunk_end])
            self._wait_for_composer_prefix(text[:chunk_end])
            chunk_number = offset // chunk_size + 1
            if chunk_number == 1 or chunk_number % 16 == 0 or chunk_number == chunk_count:
                LOGGER.debug(
                    "browser_composer_insert fallback_chunk=%s chunk_count=%s",
                    chunk_number,
                    chunk_count,
                    extra={
                        "operation": "browser.composer.insert",
                        "status": "fallback_progress",
                    },
                )
        return live_editor

    def _wait_for_composer_prefix(self, expected_text: str) -> None:
        expected = transport_fingerprint(expected_text)
        deadline = monotonic() + min(30.0, self.timeout_ms / 1000)
        observed = transport_fingerprint("")
        observed_length = 0
        while True:
            composer = self._composer()
            if composer.count() != 1:
                raise ConflictError(
                    "BROWSER_COMPOSER_AMBIGUOUS",
                    "Expected exactly one editor during segmented insertion",
                )
            value = self._composer_text_for_expected(composer, expected)
            observed = transport_fingerprint(value)
            observed_length = len(value)
            if observed == expected:
                return
            if monotonic() >= deadline:
                LOGGER.debug(
                    "browser_composer_chunk_failed expected_fingerprint=%s "
                    "observed_fingerprint=%s expected_length=%s observed_length=%s",
                    expected,
                    observed,
                    len(expected_text),
                    observed_length,
                    extra={
                        "operation": "browser.composer.insert",
                        "status": "chunk_failed",
                    },
                )
                raise ConflictError(
                    "BROWSER_COMPOSER_CHUNK_NOT_OBSERVED",
                    "Segmented composer insertion did not preserve the complete prefix",
                    evidence={
                        "expected_fingerprint": expected,
                        "observed_fingerprint": observed,
                        "expected_character_count": len(expected_text),
                        "observed_character_count": observed_length,
                    },
                )
            self._start().wait_for_timeout(100)

    def _clear_composer(self) -> None:
        composer = self._composer()
        if composer.count() != 1:
            raise ConflictError(
                "BROWSER_COMPOSER_AMBIGUOUS",
                "Expected exactly one ChatGPT message composer while clearing draft",
            )
        self._audit_composer(composer, phase="probe_clear")
        try:
            composer.click(timeout=self.timeout_ms)
            composer.focus(timeout=self.timeout_ms)
            composer.press("Control+A", timeout=self.timeout_ms)
            composer.press("Backspace", timeout=self.timeout_ms)
        except Exception as exc:
            raise ConflictError(
                "BROWSER_COMPOSER_SPIKE_CLEAR_FAILED",
                "The composer probe could not clear the editor",
            ) from exc
        empty = transport_fingerprint("")
        try:
            self._stable_composer_reads(composer, empty, reacquire=True)
        except ConflictError as exc:
            raise ConflictError(
                "BROWSER_COMPOSER_SPIKE_CLEAR_FAILED",
                "The composer probe could not prove the editor was empty",
                evidence=exc.context.evidence,
            ) from exc

    def _stable_composer_reads(
        self, composer: Any, expected: str, *, reacquire: bool = False
    ) -> tuple[str, str, str, int]:
        deadline = monotonic() + self.timeout_ms / 1000
        stable_read_1: str | None = None
        observed = transport_fingerprint("")
        observed_length = 0
        while True:
            current = self._composer() if reacquire else composer
            if current.count() != 1:
                raise ConflictError(
                    "BROWSER_COMPOSER_AMBIGUOUS",
                    "Expected exactly one editor while verifying composer content",
                )
            value = self._composer_text_for_expected(current, expected)
            observed = transport_fingerprint(value)
            observed_length = len(value)
            if observed == expected:
                if stable_read_1 is not None:
                    return stable_read_1, observed, observed, observed_length
                stable_read_1 = observed
            else:
                stable_read_1 = None
            if monotonic() >= deadline and stable_read_1 is None:
                LOGGER.debug(
                    "browser_composer_verification_failed expected_fingerprint=%s "
                    "observed_fingerprint=%s observed_length=%s",
                    expected,
                    observed,
                    observed_length,
                    extra={
                        "operation": "browser.composer.verify",
                        "status": "failed",
                    },
                )
                raise ConflictError(
                    "BROWSER_COMPOSER_FILL_FAILED",
                    "The observed editor content did not match the complete request fingerprint",
                    evidence={
                        "expected_fingerprint": expected,
                        "observed_fingerprint": observed,
                        "observed_character_count": observed_length,
                    },
                )
            self._start().wait_for_timeout(100)

    def _wait_for_composer_fingerprint(self, composer: Any, expected: str) -> None:
        self._stable_composer_reads(composer, expected, reacquire=True)

    def _composer_text(self, composer: Any) -> str:
        metadata = self._composer_metadata(composer)
        if metadata["tag_name"] in {"input", "textarea"}:
            value = composer.input_value(timeout=self.timeout_ms)
        else:
            value = composer.evaluate(
                """element => {
                    const blockTags = new Set([
                        "P", "DIV", "LI", "PRE", "BLOCKQUOTE"
                    ]);
                    const children = Array.from(element.children);
                    if (children.length && children.every(child => blockTags.has(child.tagName))) {
                        return children.map(child => child.innerText).join("\\n");
                    }
                    return element.innerText;
                }"""
            )
        if not isinstance(value, str):
            raise ConflictError(
                "BROWSER_COMPOSER_READ_FAILED",
                "The resolved ChatGPT editor did not expose textual content",
            )
        return value

    def _composer_text_for_expected(self, composer: Any, expected: str) -> str:
        primary = self._composer_text(composer)
        if transport_fingerprint(primary) == expected:
            return primary
        metadata = self._composer_metadata(composer)
        if metadata["tag_name"] in {"input", "textarea"}:
            return primary
        alternate = composer.text_content(timeout=self.timeout_ms)
        if isinstance(alternate, str) and transport_fingerprint(alternate) == expected:
            return alternate
        return primary

    def _is_visible_editor(self, candidate: Any) -> bool:
        try:
            if not candidate.is_visible():
                return False
            metadata = self._composer_metadata(candidate)
        except Exception:
            return False
        return bool(
            metadata["tag_name"] in {"input", "textarea"}
            or metadata["is_content_editable"]
            or metadata["contenteditable"] in {"true", "plaintext-only"}
        )

    def _audit_composer(self, composer: Any, *, phase: str) -> ComposerMetadata:
        metadata = self._composer_metadata(composer)
        LOGGER.debug(
            "browser_composer_audit phase=%s tag_name=%s contenteditable=%s role=%s "
            "id=%s data_testid=%s is_content_editable=%s focused=%s "
            "editable_descendant_count=%s",
            phase,
            metadata["tag_name"],
            metadata["contenteditable"],
            metadata["role"],
            metadata["id"],
            metadata["data_testid"],
            metadata["is_content_editable"],
            metadata["focused"],
            metadata["editable_descendant_count"],
            extra={"operation": "browser.composer.audit", "status": phase},
        )
        return metadata

    @staticmethod
    def _composer_metadata(composer: Any) -> ComposerMetadata:
        raw = composer.evaluate(
            """element => {
                const active = element.ownerDocument.activeElement;
                const editableSelector =
                    "textarea, input:not([type='hidden']), [contenteditable='true'], " +
                    "[contenteditable='plaintext-only']";
                return {
                    tag_name: element.tagName.toLowerCase(),
                    contenteditable: element.getAttribute('contenteditable'),
                    role: element.getAttribute('role'),
                    id: element.id || null,
                    data_testid: element.getAttribute('data-testid'),
                    is_content_editable: element.isContentEditable,
                    focused: active === element || element.contains(active),
                    editable_descendant_count: element.querySelectorAll(editableSelector).length,
                };
            }"""
        )
        if not isinstance(raw, dict):
            raise ConflictError(
                "BROWSER_COMPOSER_AUDIT_FAILED",
                "The resolved ChatGPT editor did not expose DOM metadata",
            )
        return ComposerMetadata(
            tag_name=str(raw.get("tag_name") or ""),
            contenteditable=ChatGPTWebAdapter._optional_string(raw.get("contenteditable")),
            role=ChatGPTWebAdapter._optional_string(raw.get("role")),
            id=ChatGPTWebAdapter._optional_string(raw.get("id")),
            data_testid=ChatGPTWebAdapter._optional_string(raw.get("data_testid")),
            is_content_editable=bool(raw.get("is_content_editable")),
            focused=bool(raw.get("focused")),
            editable_descendant_count=int(raw.get("editable_descendant_count") or 0),
        )

    @staticmethod
    def _optional_string(value: object) -> str | None:
        return value if isinstance(value, str) else None

    def _path(self) -> str | None:
        return conversation_path_from_page_url(str(self._start().url))

    def _assistant_for_fingerprint(self, requested_fingerprint: str) -> Any:
        turns = self._start().locator(TURN_SELECTOR)
        matches: list[int] = []
        for index in range(turns.count()):
            message = turns.nth(index)
            if (
                message.get_attribute("data-message-author-role") == "user"
                and transport_fingerprint(message.inner_text()) == requested_fingerprint
            ):
                matches.append(index)
        if len(matches) != 1 or matches[0] + 1 >= turns.count():
            raise ConflictError(
                "BROWSER_TURN_AMBIGUOUS", "Cannot prove one assistant turn for the request"
            )
        assistant = turns.nth(matches[0] + 1)
        if assistant.get_attribute("data-message-author-role") != "assistant":
            raise ConflictError(
                "BROWSER_TURN_AMBIGUOUS", "The message after the request is not an assistant turn"
            )
        return assistant

    @staticmethod
    def _assistant_content(turn: Any) -> Any:
        if turn.get_attribute("data-message-author-role") == "assistant":
            return turn
        return turn.locator(ASSISTANT_MESSAGE_SELECTOR)

    @staticmethod
    def _copy_button_for_assistant(assistant: Any) -> Any:
        current = assistant
        for depth in range(8):
            assistant_count = (
                1 if depth == 0 else current.locator(ASSISTANT_MESSAGE_SELECTOR).count()
            )
            user_count = current.locator(USER_MESSAGE_SELECTOR).count()
            if assistant_count == 1 and user_count == 0:
                button = current.get_by_role("button", name=COPY_PATTERN)
                if button.count() == 1:
                    return button
            current = current.locator("xpath=..")
        return assistant.get_by_role("button", name=COPY_PATTERN)

    def _activate_copy_and_read(self, button: Any) -> str:
        page = self._start()
        try:
            before = page.evaluate("navigator.clipboard.readText()")
        except Exception:
            before = None
        try:
            button.press("Enter", timeout=min(5000, self.timeout_ms))
            deadline = monotonic() + min(5.0, self.timeout_ms / 1000)
            while monotonic() < deadline:
                value = page.evaluate("navigator.clipboard.readText()")
                if isinstance(value, str) and value.strip() and value != before:
                    return value
                page.wait_for_timeout(50)
        except Exception as exc:
            raise ConflictError(
                "BROWSER_COPY_CAPTURE_UNAVAILABLE",
                "The Copy control could not be activated or read",
            ) from exc
        raise ConflictError(
            "BROWSER_COPY_CAPTURE_UNAVAILABLE",
            "The Copy control did not produce new clipboard content",
        )

    def _capture_gate_path(self) -> Path:
        return self.profile_dir / "helios-capture-method.json"

    @staticmethod
    def _is_profile_in_use_error(exc: Exception) -> bool:
        message = str(exc).casefold()
        return any(
            marker in message
            for marker in (
                "processsingleton",
                "profile in use",
                "profile is in use",
                "user data directory is already in use",
            )
        )
