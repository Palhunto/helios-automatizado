from __future__ import annotations

import re

LOGIN_PATTERN = re.compile(r"log in|sign in|entrar", re.IGNORECASE)
CHALLENGE_PATTERN = re.compile(
    r"captcha|verify you are human|security check|two.factor|c[oó]digo de verifica", re.IGNORECASE
)
STOP_PATTERN = re.compile(r"stop generating|parar de gerar|stop", re.IGNORECASE)
COPY_PATTERN = re.compile(r"copy|copiar", re.IGNORECASE)
SEND_PATTERN = re.compile(r"send|enviar", re.IGNORECASE)
RETRY_PATTERN = re.compile(
    r"retry|try again|tentar novamente|regenerate|gerar novamente", re.IGNORECASE
)
OPERATIONAL_ERROR_PATTERN = re.compile(
    r"something went wrong|network error|houve um erro|ocorreu um erro|"
    r"unusual activity|too many requests|tente novamente",
    re.IGNORECASE,
)

COMPOSER_TEST_ID = "#prompt-textarea"
COMPOSER_EDITOR_SELECTOR = (
    "textarea, input:not([type='hidden']), [contenteditable='true'], "
    "[contenteditable='plaintext-only']"
)
SEND_BUTTON_TEST_ID = "button[data-testid='send-button']"
TURN_SELECTOR = (
    "[data-message-author-role='user'], [data-message-author-role='assistant']"
)
USER_MESSAGE_SELECTOR = "[data-message-author-role='user']"
ASSISTANT_MESSAGE_SELECTOR = "[data-message-author-role='assistant']"
CONVERSATION_LINK_SELECTOR = "a[href^='/c/']"
