from __future__ import annotations

import json
import logging
from collections.abc import Callable
from dataclasses import asdict
from time import monotonic, sleep
from typing import NoReturn

from ebook_pipeline.browser.fingerprints import (
    captured_response_bytes,
    strict_request_text,
    transport_fingerprint,
)
from ebook_pipeline.browser.models import (
    BrowserConversation,
    BrowserInteraction,
    BrowserInteractionResolution,
    ConversationResolutionAction,
    ConversationStatus,
    InteractionKind,
    InteractionResolutionKind,
    InteractionStatus,
    SessionState,
    TurnState,
)
from ebook_pipeline.browser.persistence import BrowserPersistence
from ebook_pipeline.browser.ports import ChatProviderAdapter
from ebook_pipeline.browser.repositories import (
    BrowserConversationInvalidationRepository,
    BrowserConversationRepository,
    BrowserInteractionRepository,
    BrowserInteractionResolutionRepository,
)
from ebook_pipeline.browser.urls import is_real_conversation_path
from ebook_pipeline.config import AppConfig
from ebook_pipeline.core.errors import ConflictError, HeliosError, IntegrityError, NotFoundError
from ebook_pipeline.core.hashing import sha256_bytes
from ebook_pipeline.core.ids import new_id, utc_now
from ebook_pipeline.core.models import Artifact, ValidationIssue
from ebook_pipeline.core.runtime_config import ProjectRuntimeService
from ebook_pipeline.storage.artifacts import ArtifactStore
from ebook_pipeline.storage.database import Database
from ebook_pipeline.storage.repositories import (
    ArtifactRepository,
    ErrorRepository,
    ProjectRepository,
    StageRunRepository,
)
from ebook_pipeline.writing.models import SubmissionDisposition
from ebook_pipeline.writing.repositories import SubmissionRepository
from ebook_pipeline.writing.service import WritingService

BrowserFaultHook = Callable[[str], None]
LOGGER = logging.getLogger(__name__)
AUTOMATION_CONTRACT_VERSION = 4
AUTOMATION_REQUEST_PROMPT_VERSION = 2
ACTIVE_INTERACTION_STATUSES = frozenset(
    {
        InteractionStatus.PREPARED,
        InteractionStatus.SENDING,
        InteractionStatus.SENT,
        InteractionStatus.STREAMING,
        InteractionStatus.CAPTURED,
    }
)


class BrowserAutomationService:
    def __init__(
        self,
        config: AppConfig,
        database: Database,
        store: ArtifactStore,
        adapter: ChatProviderAdapter,
        writing: WritingService | None = None,
        *,
        fault_hook: BrowserFaultHook | None = None,
    ) -> None:
        self.config = config
        self.database = database
        self.store = store
        self.adapter = adapter
        self.writing = writing or WritingService(config, database, store)
        self.persistence = BrowserPersistence(config)
        self.runtime_config = ProjectRuntimeService(config, database, store)
        self.fault_hook = fault_hook

    def prepare_context(
        self, project_id: str, context_id: str | None = None
    ) -> BrowserInteraction:
        self._assert_browser_enabled(project_id)
        if context_id is None:
            try:
                context = self.writing.context(project_id)
            except NotFoundError:
                context = self.writing.create_context(
                    project_id,
                    contract_id="omega_writing_production",
                    contract_version=AUTOMATION_CONTRACT_VERSION,
                    request_prompt_id="helios_writing_unit_request",
                    request_prompt_version=AUTOMATION_REQUEST_PROMPT_VERSION,
                )
            if (
                context.contract_version != AUTOMATION_CONTRACT_VERSION
                or context.request_prompt_version != AUTOMATION_REQUEST_PROMPT_VERSION
            ):
                context = self.writing.create_context(
                    project_id,
                    contract_id="omega_writing_production",
                    contract_version=AUTOMATION_CONTRACT_VERSION,
                    request_prompt_id="helios_writing_unit_request",
                    request_prompt_version=AUTOMATION_REQUEST_PROMPT_VERSION,
                )
        else:
            context = self.writing.contexts.get_by_id(project_id, context_id)
        self._assert_automation_context(project_id, context.id)
        context, content = self.writing.context_package_by_id(project_id, context.id)
        if context.package_artifact_id is None:
            raise IntegrityError(
                "WRITING_CONTEXT_ARTIFACT_MISSING", "Context package is not registered"
            )
        text = strict_request_text(content)
        fingerprint = transport_fingerprint(text)
        with (
            self.database.connection() as connection,
            self.database.transaction(connection),
        ):
            conversation = self.persistence.conversation(connection, project_id, context.id)
            return self.persistence.create_interaction(
                    connection,
                    project_id=project_id,
                    conversation_id=conversation.id,
                    context_id=context.id,
                    kind=InteractionKind.CONTEXT_LOAD,
                    request_artifact_id=context.package_artifact_id,
                    request_sha256=context.package_sha256,
                    transport_fingerprint=fingerprint,
            )

    def prepare_unit(
        self,
        project_id: str,
        unit_id: str,
        *,
        context_id: str | None = None,
        reprocess: bool = False,
    ) -> BrowserInteraction:
        self._assert_browser_enabled(project_id)
        context = (
            self.writing.context(project_id)
            if context_id is None
            else self.writing.contexts.get_by_id(project_id, context_id)
        )
        self._assert_automation_context(project_id, context.id)
        with self.database.connection() as connection:
            conversation = BrowserConversationRepository(connection).for_context(context.id)
            if conversation is None or conversation.status is not ConversationStatus.READY:
                raise ConflictError(
                    "BROWSER_CONTEXT_CONVERSATION_NOT_READY",
                    "Context must be loaded into a proven conversation before unit automation",
                )
            context_load = BrowserInteractionRepository(connection).latest_for_context_kind(
                context.id, InteractionKind.CONTEXT_LOAD
            )
            if context_load is None or context_load.status is not InteractionStatus.IMPORTED:
                raise ConflictError(
                    "BROWSER_CONTEXT_LOAD_INCOMPLETE",
                    "Context acknowledgement must be captured before unit automation",
                )
        preparation = self.writing.prepare_unit_for_context(
            project_id, context.id, unit_id, reprocess=reprocess
        )
        preparation, content = self.writing.unit_request_by_id(project_id, preparation.id)
        if preparation.request_artifact_id is None:
            raise IntegrityError(
                "WRITING_PREPARATION_ARTIFACT_MISSING", "Unit request is not registered"
            )
        text = strict_request_text(content)
        with self.database.connection() as connection:
            conversation = BrowserConversationRepository(connection).for_context(context.id)
            assert conversation is not None
            with self.database.transaction(connection):
                return self.persistence.create_interaction(
                    connection,
                    project_id=project_id,
                    conversation_id=conversation.id,
                    context_id=context.id,
                    kind=InteractionKind.UNIT_REQUEST,
                    unit_id=preparation.unit_id,
                    preparation_id=preparation.id,
                    request_artifact_id=preparation.request_artifact_id,
                    request_sha256=preparation.request_sha256,
                    transport_fingerprint=transport_fingerprint(text),
                )

    def run_context(self, project_id: str, context_id: str | None = None) -> dict[str, object]:
        item = self.prepare_context(project_id, context_id)
        return self.run_interaction(item.id)

    def run_unit(
        self, project_id: str, unit_id: str, *, context_id: str | None = None
    ) -> dict[str, object]:
        item = self.prepare_unit(project_id, unit_id, context_id=context_id)
        return self.run_interaction(item.id)

    def continue_project(self, project_id: str) -> dict[str, object]:
        """Advance at most one proven operation and pause at every human/domain gate."""
        context = self.writing.context(project_id)
        with self.database.connection() as connection:
            interaction_repository = BrowserInteractionRepository(connection)
            resolution_repository = BrowserInteractionResolutionRepository(connection)
            incomplete = interaction_repository.list_incomplete(project_id)
            unresolved_blocked = [
                item
                for item in interaction_repository.list_blocked(project_id)
                if resolution_repository.for_interaction(item.id) is None
            ]
            conversation = BrowserConversationRepository(connection).for_context(context.id)
            context_load = interaction_repository.latest_for_context_kind(
                context.id, InteractionKind.CONTEXT_LOAD
            )
        if unresolved_blocked:
            raise ConflictError(
                "BROWSER_INTERACTION_BLOCKED",
                "Blocked browser interaction requires explicit operator resolution",
                evidence={"interaction_id": unresolved_blocked[-1].id},
            )
        if incomplete:
            raise ConflictError(
                "BROWSER_RECOVERY_REQUIRED",
                "Recover the incomplete browser interaction before continuing",
            )
        if conversation is None or context_load is None:
            return self.run_context(project_id, context.id)
        if context_load.status is InteractionStatus.BLOCKED:
            return self.run_context(project_id, context.id)
        if context_load.status is not InteractionStatus.IMPORTED:
            raise ConflictError(
                "BROWSER_CONTEXT_LOAD_INCOMPLETE", "Context load is not imported"
            )
        with self.database.connection() as connection:
            confirmed = connection.execute(
                "SELECT 1 FROM writing_acknowledgements "
                "WHERE context_id = ? AND confirmed_at IS NOT NULL",
                (context.id,),
            ).fetchone()
        if confirmed is None:
            return {
                "project_id": project_id,
                "status": "paused",
                "reason": "context_confirmation_required",
            }
        production_set = self.writing.production_set(project_id)
        writing_status = self.writing.status(project_id)
        production_payload = writing_status.get("production_set")
        latest_by_unit: dict[str, str | None] = {}
        if isinstance(production_payload, dict):
            units = production_payload.get("units")
            if isinstance(units, list):
                latest_by_unit = {
                    str(unit["unit_id"]): (
                        None
                        if unit.get("latest_disposition") is None
                        else str(unit["latest_disposition"])
                    )
                    for unit in units
                    if isinstance(unit, dict) and "unit_id" in unit
                }
        for selection in production_set.selections:
            if selection.status.value == "current_compatible":
                continue
            disposition = latest_by_unit.get(selection.unit_id)
            if disposition in {"review_required", "rejected"}:
                return {
                    "project_id": project_id,
                    "status": "paused",
                    "reason": disposition,
                    "unit_id": selection.unit_id,
                }
            return self.run_unit(project_id, selection.unit_id, context_id=context.id)
        return {"project_id": project_id, "status": "complete"}

    def retry_rejected(self, project_id: str, interaction_id: str) -> dict[str, object]:
        """Create one explicit, bounded repair turn; never edit the rejected response bytes."""
        with self.database.connection() as connection:
            project = ProjectRepository(connection).get(project_id)
            previous = BrowserInteractionRepository(connection).get(interaction_id)
            if (
                previous.project_id != project.id
                or previous.kind is not InteractionKind.UNIT_REQUEST
            ):
                raise NotFoundError(
                    "BROWSER_INTERACTION_NOT_FOUND", "Rejected unit interaction was not found"
                )
            if previous.status is not InteractionStatus.IMPORTED:
                raise ConflictError(
                    "BROWSER_RETRY_SOURCE_INCOMPLETE", "Only an imported rejection can be retried"
                )
            if previous.attempt >= previous.max_attempts:
                raise ConflictError(
                    "BROWSER_ATTEMPTS_EXHAUSTED", "Browser interaction retry limit was reached"
                )
            if previous.imported_entity_id is None:
                raise IntegrityError(
                    "BROWSER_IMPORT_EVIDENCE_MISSING", "Imported submission identity is missing"
                )
            submission = SubmissionRepository(connection).get(previous.imported_entity_id)
            if submission.disposition is not SubmissionDisposition.REJECTED:
                raise ConflictError(
                    "BROWSER_RETRY_NOT_REJECTED", "Only rejected submissions use repair retry"
                )
            conversation = BrowserConversationRepository(connection).get(
                previous.conversation_id
            )
        report = self.writing.unit_validation_report(project_id, submission)
        findings = report.get("findings")
        if not isinstance(findings, list):
            raise IntegrityError(
                "WRITING_VALIDATION_REPORT_INVALID", "Validation findings are unavailable"
            )
        whitelist = {
            "WRITING_CONTENT_EMPTY",
            "WRITING_CHARACTER_COUNT_INVALID",
            "WRITING_REQUIRED_HEADING_MISSING",
            "WRITING_FORBIDDEN_HEADING_PRESENT",
            "WRITING_FINAL_HEADING_INVALID",
            "WRITING_LIST_SYNTAX_FORBIDDEN",
            "WRITING_FORBIDDEN_PHRASE_PRESENT",
        }
        errors = [
            item
            for item in findings
            if isinstance(item, dict) and item.get("severity") == "error"
        ]
        codes = {str(item.get("code")) for item in errors}
        if not errors or not codes.issubset(whitelist):
            raise ConflictError(
                "BROWSER_REPAIR_NOT_DETERMINISTIC",
                "Rejected findings are outside the deterministic repair whitelist",
                evidence={"codes": sorted(codes)},
            )
        assert previous.unit_id is not None and previous.preparation_id is not None
        lines = [
            "A resposta anterior foi rejeitada por invariantes objetivas.",
            f"Reescreva exclusivamente a unidade {previous.unit_id}, corrigindo:",
        ]
        ordered_errors = sorted(errors, key=lambda value: str(value.get("code")))
        lines.extend(
            f"- {item['code']}: {item.get('message', '')}" for item in ordered_errors
        )
        lines.append("Entregue somente o texto integral revisado da unidade.")
        request = ("\n".join(lines) + "\n").encode("utf-8")
        digest = sha256_bytes(request)
        attempt = previous.attempt
        attempt_ordinal = attempt + 1
        run = self.persistence.run_states.new_run(
            project_id=project.id,
            stage_id="chatgpt_browser_automation",
            unit_id=f"unit:{previous.unit_id}",
            input_hash=digest,
            max_attempts=self.config.max_attempts,
            version=attempt_ordinal,
            supersedes_run_id=previous.stage_run_id,
        )
        stored = self.store.write_bytes(
            project.artifact_root,
            f"browser/requests/{previous.unit_id}/repair-{attempt_ordinal:04d}.txt",
            request,
        )
        with (
            self.database.connection() as connection,
            self.database.transaction(connection),
        ):
            StageRunRepository(connection).add(run)
            artifact = ArtifactRepository(connection).add_idempotent(
                    Artifact(
                        id=new_id(),
                        project_id=project.id,
                        stage_run_id=run.id,
                        artifact_type="browser_repair_request",
                        relative_path=stored.relative_path,
                        sha256=stored.sha256,
                        byte_size=stored.byte_size,
                        version=attempt_ordinal,
                        created_at=utc_now(),
                    )
            )
            item = self.persistence.create_interaction(
                    connection,
                    project_id=project.id,
                    conversation_id=conversation.id,
                    context_id=previous.context_id,
                    kind=InteractionKind.UNIT_REQUEST,
                    unit_id=previous.unit_id,
                    preparation_id=previous.preparation_id,
                    request_artifact_id=artifact.id,
                    request_sha256=digest,
                    transport_fingerprint=transport_fingerprint(strict_request_text(request)),
                    attempt=attempt,
                    supersedes_interaction_id=previous.id,
                    stage_run=run,
            )
        return self.run_interaction(item.id)

    def run_interaction(self, interaction_id: str) -> dict[str, object]:
        with self.database.connection() as connection:
            item = BrowserInteractionRepository(connection).get(interaction_id)
            conversation = BrowserConversationRepository(connection).get(item.conversation_id)
            project = ProjectRepository(connection).get(item.project_id)
        if item.status is InteractionStatus.IMPORTED:
            return self._payload(item)
        if item.status is InteractionStatus.BLOCKED:
            raise ConflictError(
                "BROWSER_INTERACTION_BLOCKED",
                "Blocked browser interaction requires explicit operator resolution",
                evidence={"interaction_id": item.id},
            )
        self._ensure_session_or_block(item)
        if not self.adapter.capture_gate_ready():
            self._block(
                item,
                "BROWSER_CAPTURE_SPIKE_REQUIRED",
                "Run and approve the short/long capture spike before real sends",
            )
        if item.status is InteractionStatus.CAPTURED:
            return self._import_captured(project.id, item)
        if item.status is InteractionStatus.PREPARED:
            content = self._request_bytes(project.id, item)
            request_text = strict_request_text(content)
            if transport_fingerprint(request_text) != item.transport_fingerprint:
                self._block(
                    item,
                    "BROWSER_TRANSPORT_FINGERPRINT_MISMATCH",
                    "Request bytes no longer match their transport fingerprint",
                )
            if conversation.status is ConversationStatus.PROVISIONING:
                self.adapter.create_conversation()
                baseline = self.adapter.list_conversation_paths()
                with (
                    self.database.connection() as connection,
                    self.database.transaction(connection),
                ):
                    conversation = self.persistence.record_provisioning_baseline(
                        connection, conversation, baseline
                    )
            elif conversation.conversation_path is not None:
                self.adapter.open_conversation(conversation.conversation_path)
            def persist_send_attempt_started() -> None:
                nonlocal item
                with (
                    self.database.connection() as connection,
                    self.database.transaction(connection),
                ):
                    current = BrowserInteractionRepository(connection).get(item.id)
                    item = self.persistence.begin_send(connection, current)

            self.adapter.send_message(
                request_text,
                on_send_attempt_started=persist_send_attempt_started,
            )
            self._checkpoint("browser.after_send")
            with self.database.connection() as connection:
                item = BrowserInteractionRepository(connection).get(item.id)
            if item.status is not InteractionStatus.SENDING:
                raise IntegrityError(
                    "BROWSER_SEND_BOUNDARY_NOT_PERSISTED",
                    "Adapter returned without recording the send-attempt-started boundary",
                )
        return self._observe_capture_import(project.id, item, conversation)

    def reprobe_blocked_interaction(self, interaction_id: str) -> dict[str, object]:
        """Reinspect external evidence for one blocked interaction without resending."""
        with self.database.connection() as connection:
            item = BrowserInteractionRepository(connection).get(interaction_id)
            conversation = BrowserConversationRepository(connection).get(item.conversation_id)
        if item.status is not InteractionStatus.BLOCKED:
            raise ConflictError(
                "BROWSER_RECOVERY_SOURCE_INVALID",
                "Recovery reprobe requires a blocked browser interaction",
            )
        if conversation.conversation_path is None:
            return self._blocked_reprobe_result(
                item, "conversation_path_missing", observations=0
            )
        if not is_real_conversation_path(conversation.conversation_path):
            return {
                "outcome": "still_blocked",
                "interaction_id": item.id,
                "reason": "invalid_conversation_path",
                "observations": 0,
            }
        session = self.adapter.ensure_ready()
        if session is not SessionState.READY:
            return self._blocked_reprobe_result(
                item, f"session_{session.value}", observations=0
            )
        if not self.adapter.capture_gate_ready():
            return self._blocked_reprobe_result(
                item, "capture_gate_not_ready", observations=0
            )
        self.adapter.open_conversation(conversation.conversation_path)
        deadline = monotonic() + self.config.browser_timeout_seconds
        observations = 0
        while True:
            observations += 1
            inspection = self.adapter.inspect_turn(item.transport_fingerprint)
            if inspection.conversation_path not in {None, conversation.conversation_path}:
                return self._blocked_reprobe_result(
                    item, "wrong_conversation", observations=observations
                )
            if inspection.state is TurnState.AMBIGUOUS:
                return self._blocked_reprobe_result(
                    item, "turn_ambiguous", observations=observations
                )
            if inspection.state is TurnState.NOT_SENT:
                if monotonic() >= deadline:
                    return self._blocked_reprobe_result(
                        item, "user_turn_not_observed", observations=observations
                    )
                sleep(0.25)
                continue
            if inspection.observed_user_turn_fingerprint != item.transport_fingerprint:
                return self._blocked_reprobe_result(
                    item, "user_turn_fingerprint_not_observed", observations=observations
                )
            with (
                self.database.connection() as connection,
                self.database.transaction(connection),
            ):
                current = BrowserInteractionRepository(connection).get(item.id)
                item = self.persistence.resume_blocked_from_proven_user_turn(
                    connection,
                    current,
                    conversation_path=conversation.conversation_path,
                    observed_user_turn_fingerprint=(
                        inspection.observed_user_turn_fingerprint
                    ),
                    evidence={
                        "conversation_path": conversation.conversation_path,
                        "turn_state": inspection.state.value,
                    },
                )
            result = self._observe_capture_import(item.project_id, item, conversation)
            return {
                "outcome": "recovered",
                "interaction_id": item.id,
                "observations": observations,
                "result": result,
            }

    def status(self, project_id: str) -> dict[str, object]:
        with self.database.connection() as connection:
            ProjectRepository(connection).get(project_id)
            rows = connection.execute(
                "SELECT id FROM browser_conversations WHERE project_id = ? ORDER BY created_at",
                (project_id,),
            ).fetchall()
            conversations = [
                BrowserConversationRepository(connection).get(str(row["id"])) for row in rows
            ]
            invalidations = BrowserConversationInvalidationRepository(connection)
            conversation_payload = []
            for conversation in conversations:
                invalidation = invalidations.for_conversation(conversation.id)
                conversation_payload.append(
                    {
                        **asdict(conversation),
                        "status": conversation.status.value,
                        "reusable": (
                            invalidation is None
                            and conversation.status is ConversationStatus.READY
                            and conversation.conversation_path is not None
                            and is_real_conversation_path(conversation.conversation_path)
                        ),
                        "invalidation": (
                            None
                            if invalidation is None
                            else {
                                **asdict(invalidation),
                                "evidence": json.loads(invalidation.evidence_json),
                            }
                        ),
                    }
                )
            interactions = connection.execute(
                "SELECT status, count(*) AS count FROM browser_interactions "
                "WHERE project_id = ? GROUP BY status ORDER BY status",
                (project_id,),
            ).fetchall()
            interaction_repository = BrowserInteractionRepository(connection)
            resolution_repository = BrowserInteractionResolutionRepository(connection)
            all_interactions = interaction_repository.list_for_project(project_id)
            active_payload = [
                {
                    "interaction_id": item.id,
                    "conversation_id": item.conversation_id,
                    "context_id": item.context_id,
                    "kind": item.kind.value,
                    "unit_id": item.unit_id,
                    "status": item.status.value,
                    "created_at": item.created_at,
                }
                for item in all_interactions
                if item.status in ACTIVE_INTERACTION_STATUSES
            ]
            blocked = interaction_repository.list_blocked(project_id)
            blocked_payload = [
                {
                    "interaction_id": item.id,
                    "context_id": item.context_id,
                    "kind": item.kind.value,
                    "unit_id": item.unit_id,
                    "operator_abandoned": (
                        resolution_repository.for_interaction(item.id) is not None
                    ),
                }
                for item in blocked
            ]
        return {
            "project_id": project_id,
            "conversations": conversation_payload,
            "interaction_counts": {str(row["status"]): int(row["count"]) for row in interactions},
            "active_interactions": active_payload,
            "blocked_interactions": blocked_payload,
        }

    def interaction_show(
        self, project_id: str, interaction_id: str | None = None
    ) -> dict[str, object]:
        with self.database.connection() as connection:
            ProjectRepository(connection).get(project_id)
            interactions = BrowserInteractionRepository(connection)
            if interaction_id is None:
                all_interactions = interactions.list_for_project(project_id)
                active = [
                    item
                    for item in all_interactions
                    if item.status in ACTIVE_INTERACTION_STATUSES
                ]
                if len(active) > 1:
                    candidate_ids = [candidate.id for candidate in active]
                    raise ConflictError(
                        "BROWSER_INTERACTION_SELECTION_AMBIGUOUS",
                        "More than one active browser interaction requires an explicit ID: "
                        + ", ".join(candidate_ids),
                        evidence={
                            "candidates": [
                                {
                                    "interaction_id": candidate.id,
                                    "conversation_id": candidate.conversation_id,
                                    "created_at": candidate.created_at,
                                    "status": candidate.status.value,
                                }
                                for candidate in active
                            ]
                        },
                    )
                if active:
                    item = active[0]
                else:
                    unresolved = [
                        candidate
                        for candidate in all_interactions
                        if candidate.status is InteractionStatus.BLOCKED
                        and BrowserInteractionResolutionRepository(
                            connection
                        ).for_interaction(candidate.id)
                        is None
                    ]
                    if len(unresolved) > 1:
                        candidate_ids = [candidate.id for candidate in unresolved]
                        raise ConflictError(
                            "BROWSER_INTERACTION_SELECTION_AMBIGUOUS",
                            "More than one unresolved interaction requires an explicit ID: "
                            + ", ".join(candidate_ids),
                            evidence={
                                "candidates": [
                                    {
                                        "interaction_id": candidate.id,
                                        "conversation_id": candidate.conversation_id,
                                        "created_at": candidate.created_at,
                                        "status": candidate.status.value,
                                    }
                                    for candidate in unresolved
                                ]
                            },
                        )
                    if not unresolved:
                        raise NotFoundError(
                            "BROWSER_INTERACTION_NOT_FOUND",
                            "No active or unresolved browser interaction was found; provide an ID",
                        )
                    item = unresolved[0]
            else:
                item = interactions.get(interaction_id)
                if item.project_id != project_id:
                    raise NotFoundError(
                        "BROWSER_INTERACTION_NOT_FOUND", "Browser interaction was not found"
                    )
            conversation = BrowserConversationRepository(connection).get(item.conversation_id)
            stage_run = StageRunRepository(connection).get(item.stage_run_id)
            resolution = BrowserInteractionResolutionRepository(connection).for_interaction(
                item.id
            )
            conversation_invalidation = BrowserConversationInvalidationRepository(
                connection
            ).for_conversation(conversation.id)
            events = interactions.events(item.id)
        return {
            "interaction": self._payload(item),
            "stage_run": {**asdict(stage_run), "status": stage_run.status.value},
            "conversation": {
                **asdict(conversation),
                "status": conversation.status.value,
                "reusable": (
                    conversation_invalidation is None
                    and conversation.status is ConversationStatus.READY
                    and conversation.conversation_path is not None
                    and is_real_conversation_path(conversation.conversation_path)
                ),
                "invalidation": (
                    None
                    if conversation_invalidation is None
                    else {
                        **asdict(conversation_invalidation),
                        "evidence": json.loads(conversation_invalidation.evidence_json),
                    }
                ),
            },
            "events": events,
            "operator_resolution": self._resolution_payload(resolution),
        }

    def abandon_interaction(
        self,
        project_id: str,
        interaction_id: str,
        *,
        operator: str,
        reason: str,
    ) -> dict[str, object]:
        operator = operator.strip()
        reason = reason.strip()
        if not operator:
            raise ConflictError(
                "BROWSER_ABANDON_OPERATOR_REQUIRED",
                "Operator identity is required for an abandonment decision",
            )
        if not reason:
            raise ConflictError(
                "BROWSER_ABANDON_REASON_REQUIRED",
                "A reason is required for an abandonment decision",
            )
        with (
            self.database.connection() as connection,
            self.database.transaction(connection),
        ):
            ProjectRepository(connection).get(project_id)
            interactions = BrowserInteractionRepository(connection)
            item = interactions.get(interaction_id)
            if item.project_id != project_id:
                raise NotFoundError(
                    "BROWSER_INTERACTION_NOT_FOUND", "Browser interaction was not found"
                )
            if item.status is not InteractionStatus.BLOCKED:
                raise ConflictError(
                    "BROWSER_ABANDON_STATE_INVALID",
                    "Only a blocked or ambiguous browser interaction can be abandoned",
                    evidence={"interaction_id": item.id, "status": item.status.value},
                )
            resolutions = BrowserInteractionResolutionRepository(connection)
            existing = resolutions.for_interaction(item.id)
            if existing is not None:
                if existing.operator == operator and existing.reason == reason:
                    existing_payload = self._resolution_payload(existing)
                    assert existing_payload is not None
                    return existing_payload
                raise ConflictError(
                    "BROWSER_INTERACTION_ALREADY_RESOLVED",
                    "Browser interaction already has an operator resolution",
                    evidence={"interaction_id": item.id, "resolution_id": existing.id},
                )
            conversation = BrowserConversationRepository(connection).get(item.conversation_id)
            recoverable_statuses = {
                InteractionStatus.PREPARED,
                InteractionStatus.SENDING,
                InteractionStatus.SENT,
                InteractionStatus.STREAMING,
                InteractionStatus.CAPTURED,
            }
            other_recoverable = [
                value
                for value in interactions.list_for_conversation(conversation.id)
                if value.id != item.id and value.status in recoverable_statuses
            ]
            close_provisioning = (
                conversation.status is ConversationStatus.PROVISIONING
                and conversation.conversation_path is None
                and conversation.first_turn_fingerprint is None
                and not other_recoverable
            )
            action = (
                ConversationResolutionAction.PROVISIONING_ATTEMPT_CLOSED
                if close_provisioning
                else ConversationResolutionAction.RETAINED
            )
            snapshot = {
                **asdict(conversation),
                "status": conversation.status.value,
            }
            if close_provisioning:
                self.persistence.close_provisioning_conversation(connection, conversation)
            now = utc_now()
            resolution = BrowserInteractionResolution(
                id=new_id(),
                interaction_id=item.id,
                project_id=item.project_id,
                resolution=InteractionResolutionKind.OPERATOR_ABANDONED,
                operator=operator,
                reason=reason,
                conversation_action=action,
                evidence_json=json.dumps(
                    {
                        "decision_scope": "external_send_outcome_unprovable",
                        "conversation_snapshot": snapshot,
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ),
                created_at=now,
            )
            resolutions.add(resolution)
            interactions.event(
                item.id,
                item.project_id,
                item.status,
                item.status,
                {
                    "event_type": "operator_resolution",
                    "resolution_id": resolution.id,
                    "resolution": resolution.resolution.value,
                    "conversation_action": resolution.conversation_action.value,
                },
            )
        payload = self._resolution_payload(resolution)
        assert payload is not None
        return payload

    def validate(self, project_id: str) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        with self.database.connection() as connection:
            project = ProjectRepository(connection).get(project_id)
            rows = connection.execute(
                "SELECT id FROM browser_interactions WHERE project_id = ?", (project_id,)
            ).fetchall()
            repository = BrowserInteractionRepository(connection)
            conversation_rows = connection.execute(
                "SELECT c.id, c.conversation_path, i.id AS invalidation_id "
                "FROM browser_conversations c LEFT JOIN browser_conversation_invalidations i "
                "ON i.conversation_id = c.id WHERE c.project_id = ?",
                (project_id,),
            ).fetchall()
            for conversation_row in conversation_rows:
                path = conversation_row["conversation_path"]
                if (
                    conversation_row["invalidation_id"] is None
                    and path is not None
                    and not is_real_conversation_path(str(path))
                ):
                    issues.append(
                        ValidationIssue(
                            "BROWSER_CONVERSATION_PATH_INVALID",
                            "Persisted conversation path is not a canonical /c/<uuid> path",
                            relative_path=str(conversation_row["id"]),
                        )
                    )
            for row in rows:
                item = repository.get(str(row["id"]))
                try:
                    request_row = connection.execute(
                        "SELECT sha256, relative_path, byte_size FROM artifacts WHERE id = ? "
                        "AND project_id = ?",
                        (item.request_artifact_id, project.id),
                    ).fetchone()
                    if request_row is None or str(request_row["sha256"]) != item.request_sha256:
                        raise IntegrityError(
                            "BROWSER_REQUEST_ARTIFACT_INVALID", "Request artifact binding differs"
                        )
                    inspected = self.store.inspect(
                        project.artifact_root, str(request_row["relative_path"])
                    )
                    if (
                        inspected.sha256 != str(request_row["sha256"])
                        or inspected.byte_size != int(request_row["byte_size"])
                    ):
                        raise IntegrityError(
                            "BROWSER_REQUEST_ARTIFACT_INVALID", "Request artifact bytes differ"
                        )
                    if item.status in {InteractionStatus.CAPTURED, InteractionStatus.IMPORTED}:
                        self._response_bytes(project.id, item)
                    run = StageRunRepository(connection).get(item.stage_run_id)
                    if item.status is InteractionStatus.IMPORTED and run.status.value != "done":
                        raise IntegrityError(
                            "BROWSER_STAGE_RUN_DIVERGENT", "Imported interaction run is not done"
                        )
                except HeliosError as exc:
                    issues.append(ValidationIssue(exc.code, exc.message))
        return issues

    def _observe_capture_import(
        self,
        project_id: str,
        item: BrowserInteraction,
        conversation: BrowserConversation,
    ) -> dict[str, object]:
        if conversation.conversation_path is not None:
            if not is_real_conversation_path(conversation.conversation_path):
                raise IntegrityError(
                    "BROWSER_CONVERSATION_PATH_INVALID",
                    "Persisted conversation path is not a canonical /c/<uuid> path",
                )
            self.adapter.open_conversation(conversation.conversation_path)
        elif conversation.status is not ConversationStatus.PROVISIONING:
            raise IntegrityError(
                "BROWSER_BOOTSTRAP_RECOVERY_REQUIRED",
                "Conversation has no proven page URL; run browser recover",
                recoverable=True,
            )
        user_turn_proven = item.status in {
            InteractionStatus.SENT,
            InteractionStatus.STREAMING,
        }
        proof_deadline = monotonic() + self.config.browser_timeout_seconds
        response_deadline = (
            monotonic() + self.config.browser_timeout_seconds
            if user_turn_proven
            else None
        )
        while True:
            inspection = self.adapter.inspect_turn(item.transport_fingerprint)
            if (
                conversation.conversation_path is not None
                and inspection.conversation_path not in {None, conversation.conversation_path}
            ):
                self._block(
                    item,
                    "BROWSER_WRONG_CONVERSATION",
                    "Observed response belongs to another conversation",
                )
            if inspection.state is TurnState.AMBIGUOUS:
                self._block(
                    item,
                    "BROWSER_TURN_AMBIGUOUS",
                    "Browser state cannot prove the requested user turn",
                    inspection.evidence,
                )
            if inspection.state is TurnState.NOT_SENT:
                active_deadline = response_deadline if user_turn_proven else proof_deadline
                assert active_deadline is not None
                if monotonic() >= active_deadline:
                    if user_turn_proven:
                        self._block(
                            item,
                            "BROWSER_RESPONSE_TIMEOUT",
                            "Previously proven turn did not reach a complete response in time",
                        )
                    self._block(
                        item,
                        "BROWSER_SEND_NOT_PROVABLE",
                        "Browser could not prove the user turn before the configured timeout",
                    )
                sleep(0.25)
                continue
            if not user_turn_proven:
                if inspection.observed_user_turn_fingerprint != item.transport_fingerprint:
                    self._block(
                        item,
                        "BROWSER_USER_TURN_FINGERPRINT_MISMATCH",
                        "Adapter did not provide the matching fingerprint of an observed user turn",
                    )
                observed_path = self.adapter.current_conversation_path()
                if observed_path is None:
                    if monotonic() >= proof_deadline:
                        self._block(
                            item,
                            "BROWSER_CONVERSATION_PATH_NOT_OBSERVED",
                            "A matching user turn exists but page.url has no real "
                            "conversation path",
                        )
                    sleep(0.25)
                    continue
                if not is_real_conversation_path(observed_path):
                    self._block(
                        item,
                        "BROWSER_CONVERSATION_PATH_INVALID",
                        "Observed page URL did not contain a canonical /c/<uuid> path",
                    )
                if inspection.conversation_path not in {None, observed_path}:
                    self._block(
                        item,
                        "BROWSER_WRONG_CONVERSATION",
                        "Observed user turn belongs to another conversation",
                    )
                with (
                    self.database.connection() as connection,
                    self.database.transaction(connection),
                ):
                    current = BrowserInteractionRepository(connection).get(item.id)
                    current_conversation = BrowserConversationRepository(connection).get(
                        conversation.id
                    )
                    item, conversation = self.persistence.prove_user_turn_and_bind_conversation(
                        connection,
                        current,
                        current_conversation,
                        observed_path,
                        inspection.observed_user_turn_fingerprint,
                    )
                user_turn_proven = True
                response_deadline = monotonic() + self.config.browser_timeout_seconds
                LOGGER.debug(
                    "browser_send checkpoint=user_turn_observed",
                    extra={
                        "operation": "browser.send_message",
                        "status": "user_turn_observed",
                    },
                )
            if inspection.state is TurnState.STREAMING:
                if item.status is InteractionStatus.SENT:
                    with (
                        self.database.connection() as connection,
                        self.database.transaction(connection),
                    ):
                        item = self.persistence.transition(
                            connection, item, InteractionStatus.STREAMING
                        )
                    self._checkpoint("browser.streaming")
                assert response_deadline is not None
                if monotonic() >= response_deadline:
                    self._block(
                        item,
                        "BROWSER_RESPONSE_TIMEOUT",
                        "Response did not reach a proven complete state before timeout",
                    )
                sleep(0.25)
                continue
            if inspection.state is TurnState.COMPLETE:
                captured = captured_response_bytes(
                    self.adapter.capture_response(item.transport_fingerprint)
                )
                if not captured.strip():
                    self._block(item, "BROWSER_RESPONSE_EMPTY", "Captured response is empty")
                stored = self.store.write_bytes(
                    self._project_root(project_id),
                    f"browser/responses/{item.id}/attempt-{item.attempt:04d}.txt",
                    captured,
                )
                self._checkpoint("browser.response_stored")
                with self.database.connection() as connection:
                    project = ProjectRepository(connection).get(project_id)
                    with self.database.transaction(connection):
                        item = self.persistence.register_response(
                            connection,
                            project,
                            item,
                            stored,
                            self.config.browser_capture_method_version,
                        )
                        item = self.persistence.transition(
                            connection, item, InteractionStatus.CAPTURED
                        )
                self._checkpoint("browser.response_captured")
                return self._import_captured(project_id, item, captured)

    def _blocked_reprobe_result(
        self, item: BrowserInteraction, reason: str, *, observations: int
    ) -> dict[str, object]:
        with (
            self.database.connection() as connection,
            self.database.transaction(connection),
        ):
            current = BrowserInteractionRepository(connection).get(item.id)
            if current.status is InteractionStatus.BLOCKED:
                BrowserInteractionRepository(connection).event(
                    current.id,
                    current.project_id,
                    current.status,
                    current.status,
                    {
                        "event_type": "recovery_reprobe",
                        "outcome": "still_blocked",
                        "reason": reason,
                        "observations": observations,
                    },
                )
        return {
            "outcome": "still_blocked",
            "interaction_id": item.id,
            "reason": reason,
            "observations": observations,
        }

    def _import_captured(
        self, project_id: str, item: BrowserInteraction, response: bytes | None = None
    ) -> dict[str, object]:
        if response is None:
            response = self._response_bytes(project_id, item)
        if sha256_bytes(response) != item.response_sha256:
            self._block(
                item,
                "BROWSER_RESPONSE_HASH_MISMATCH",
                "Captured bytes differ from the registered response artifact",
            )
        if item.kind is InteractionKind.CONTEXT_LOAD:
            acknowledgement = self.writing.acknowledge_context_by_id(
                project_id, item.context_id, response
            )
            entity_type = "writing_acknowledgement"
            entity_id = acknowledgement.id
            disposition: SubmissionDisposition | None = None
            if acknowledgement.raw_sha256 != item.response_sha256:
                raise IntegrityError(
                    "BROWSER_M2_IMPORT_HASH_MISMATCH", "M2 acknowledgement bytes differ"
                )
        else:
            assert item.preparation_id is not None
            submission = self.writing.import_unit_by_preparation_id(
                project_id, item.preparation_id, response
            )
            entity_type = "text_unit_submission"
            entity_id = submission.id
            disposition = submission.disposition
            if submission.raw_sha256 != item.response_sha256:
                raise IntegrityError("BROWSER_M2_IMPORT_HASH_MISMATCH", "M2 raw bytes differ")
        self._checkpoint("browser.after_m2_import")
        with (
            self.database.connection() as connection,
            self.database.transaction(connection),
        ):
            item = self.persistence.set_import_identity(
                connection, item, entity_type, entity_id
            )
            item = self.persistence.transition(connection, item, InteractionStatus.IMPORTED)
        payload = self._payload(item)
        if entity_type == "text_unit_submission":
            assert disposition is not None
            payload["disposition"] = disposition.value
            payload["paused"] = disposition is not SubmissionDisposition.ACCEPTED
        else:
            payload["confirmation_required"] = True
        return payload

    def _request_bytes(self, project_id: str, item: BrowserInteraction) -> bytes:
        with self.database.connection() as connection:
            project = ProjectRepository(connection).get(project_id)
            artifact = ArtifactRepository(connection).list_for_project(project.id)
            bound = next(
                (value for value in artifact if value.id == item.request_artifact_id), None
            )
            if bound is None or bound.sha256 != item.request_sha256:
                raise IntegrityError(
                    "BROWSER_REQUEST_ARTIFACT_INVALID", "Request artifact binding differs"
                )
            inspected = self.store.inspect(project.artifact_root, bound.relative_path)
            if inspected.sha256 != bound.sha256 or inspected.byte_size != bound.byte_size:
                raise IntegrityError(
                    "BROWSER_REQUEST_ARTIFACT_INVALID", "Request artifact bytes differ"
                )
            return self.store.resolve(project.artifact_root, bound.relative_path).read_bytes()

    def _response_bytes(self, project_id: str, item: BrowserInteraction) -> bytes:
        if item.response_artifact_id is None or item.response_sha256 is None:
            raise IntegrityError(
                "BROWSER_RESPONSE_ARTIFACT_MISSING", "Response artifact is not registered"
            )
        with self.database.connection() as connection:
            project = ProjectRepository(connection).get(project_id)
            artifacts = ArtifactRepository(connection).list_for_project(project.id)
            artifact = next(
                (value for value in artifacts if value.id == item.response_artifact_id), None
            )
            if artifact is None or artifact.sha256 != item.response_sha256:
                raise IntegrityError(
                    "BROWSER_RESPONSE_ARTIFACT_INVALID", "Response artifact binding differs"
                )
            inspected = self.store.inspect(project.artifact_root, artifact.relative_path)
            if inspected.sha256 != artifact.sha256 or inspected.byte_size != artifact.byte_size:
                raise IntegrityError(
                    "BROWSER_RESPONSE_ARTIFACT_INVALID", "Response artifact bytes differ"
                )
            return self.store.resolve(project.artifact_root, artifact.relative_path).read_bytes()

    def _assert_automation_context(self, project_id: str, context_id: str) -> None:
        context = self.writing.contexts.get_by_id(project_id, context_id)
        contract = self.writing.contexts.resolve_contract(context)
        with self.database.connection() as connection:
            required = len(contract.model.units)
            row = connection.execute(
                "SELECT count(*) FROM writing_unit_academic_projections WHERE context_id = ?",
                (context_id,),
            ).fetchone()
            if row is None or int(row[0]) != required:
                raise ConflictError(
                    "WRITING_CONTEXT_NOT_AUTOMATION_READY",
                    "WritingContext lacks eager projections for every contract unit",
                )

    def _assert_browser_enabled(self, project_id: str) -> None:
        runtime = self.runtime_config.resolve(project_id)
        if not runtime.model.browser_automation_enabled:
            raise ConflictError(
                "BROWSER_AUTOMATION_DISABLED", "Project browser automation is disabled"
            )

    def _ensure_session_or_block(self, item: BrowserInteraction) -> None:
        state = self.adapter.ensure_ready()
        if state is SessionState.READY:
            return
        code = {
            SessionState.LOGIN_REQUIRED: "BROWSER_LOGIN_REQUIRED",
            SessionState.CHALLENGE: "BROWSER_SECURITY_CHALLENGE",
            SessionState.EXPIRED: "BROWSER_SESSION_EXPIRED",
        }[state]
        self._block(item, code, "Browser session requires explicit operator action")

    def _block(
        self,
        item: BrowserInteraction,
        code: str,
        message: str,
        evidence: dict[str, object] | None = None,
    ) -> NoReturn:
        with self.database.connection() as connection:
            current = BrowserInteractionRepository(connection).get(item.id)
            if current.status not in {InteractionStatus.BLOCKED, InteractionStatus.IMPORTED}:
                with self.database.transaction(connection):
                    self.persistence.transition(
                        connection,
                        current,
                        InteractionStatus.BLOCKED,
                        evidence={"error_code": code, **(evidence or {})},
                    )
                    ErrorRepository(connection).add(
                        project_id=current.project_id,
                        stage_run_id=current.stage_run_id,
                        code=code,
                        message=message,
                        recoverable=False,
                        evidence=evidence,
                    )
        raise IntegrityError(code, message, evidence=evidence)

    def _project_root(self, project_id: str) -> str:
        with self.database.connection() as connection:
            return ProjectRepository(connection).get(project_id).artifact_root

    def _checkpoint(self, name: str) -> None:
        if self.fault_hook is not None:
            self.fault_hook(name)

    @staticmethod
    def _payload(item: BrowserInteraction) -> dict[str, object]:
        return {**asdict(item), "status": item.status.value, "kind": item.kind.value}

    @staticmethod
    def _resolution_payload(
        resolution: BrowserInteractionResolution | None,
    ) -> dict[str, object] | None:
        if resolution is None:
            return None
        return {
            "id": resolution.id,
            "interaction_id": resolution.interaction_id,
            "project_id": resolution.project_id,
            "resolution": resolution.resolution.value,
            "operator": resolution.operator,
            "reason": resolution.reason,
            "conversation_action": resolution.conversation_action.value,
            "evidence": json.loads(resolution.evidence_json),
            "created_at": resolution.created_at,
        }
